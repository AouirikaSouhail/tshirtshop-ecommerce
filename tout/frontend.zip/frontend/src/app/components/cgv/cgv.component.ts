import { Component } from '@angular/core';

@Component({
  selector: 'app-cgv',
  templateUrl: './cgv.component.html',
  styleUrl: './cgv.component.css'
})
export class CgvComponent {

}
